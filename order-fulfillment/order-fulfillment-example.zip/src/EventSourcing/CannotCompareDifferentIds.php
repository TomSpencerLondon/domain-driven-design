<?php namespace OrderFulfillment\EventSourcing;

class CannotCompareDifferentIds extends \Exception {

}
