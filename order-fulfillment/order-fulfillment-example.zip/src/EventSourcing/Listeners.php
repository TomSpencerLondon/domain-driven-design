<?php namespace OrderFulfillment\EventSourcing;

final class Listeners extends TypedCollection {

    protected $collectionType = Listener::class;
}