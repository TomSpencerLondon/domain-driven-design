<?php namespace OrderFulfillment\EventSourcing;

class StreamId extends Id {}