<?php namespace OrderFulfillment\EventSourcing;

final class Projections extends TypedCollection {

    protected $collectionType = Projection::class;
}