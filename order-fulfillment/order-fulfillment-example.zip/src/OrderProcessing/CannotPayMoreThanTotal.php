<?php namespace OrderFulfillment\OrderProcessing;

class CannotPayMoreThanTotal extends \Exception {

}