<?php namespace OrderFulfillment\OrderProcessing;

use OrderFulfillment\EventSourcing\Id;

class ProductId extends Id {}
