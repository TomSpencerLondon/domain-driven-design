<?php namespace OrderFulfillment\OrderProcessing;

use OrderFulfillment\EventSourcing\Id;

class CustomerId extends Id {}