<?php namespace OrderFulfillment\OrderProcessing;

class CannotFulfillAnOrderThatHasNotBeenCompleted extends \Exception {

}