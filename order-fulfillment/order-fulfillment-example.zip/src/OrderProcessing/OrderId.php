<?php namespace OrderFulfillment\OrderProcessing;

use OrderFulfillment\EventSourcing\StreamId;

class OrderId extends StreamId {}
