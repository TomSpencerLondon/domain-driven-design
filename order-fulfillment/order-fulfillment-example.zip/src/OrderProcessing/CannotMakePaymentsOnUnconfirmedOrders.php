<?php namespace OrderFulfillment\OrderProcessing;

class CannotMakePaymentsOnUnconfirmedOrders extends \Exception {

}