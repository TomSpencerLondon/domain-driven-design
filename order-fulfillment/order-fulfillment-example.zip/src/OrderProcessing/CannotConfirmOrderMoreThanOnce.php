<?php namespace OrderFulfillment\OrderProcessing;

class CannotConfirmOrderMoreThanOnce extends \Exception {

}