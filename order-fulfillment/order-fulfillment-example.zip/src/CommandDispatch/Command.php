<?php namespace OrderFulfillment\CommandDispatch;

interface Command {}
