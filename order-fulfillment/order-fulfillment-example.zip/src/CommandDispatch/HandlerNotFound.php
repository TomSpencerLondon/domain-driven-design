<?php namespace OrderFulfillment\CommandDispatch;

class HandlerNotFound extends \Exception {}
