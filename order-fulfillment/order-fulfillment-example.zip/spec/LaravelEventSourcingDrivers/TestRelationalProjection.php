<?php namespace spec\OrderFulfillment\LaravelEventSourcingDrivers;

use OrderFulfillment\LaravelEventSourcingDrivers\RelationalProjection;

class TestRelationalProjection extends RelationalProjection {

    public function name() : string {

    }

    public function reset() : void {

    }

    public function tableName(): string {

    }
}