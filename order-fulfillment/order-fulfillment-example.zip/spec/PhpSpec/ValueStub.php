<?php namespace spec\OrderFulfillment\PhpSpec;

use OrderFulfillment\EventSourcing\Id;

class ValueStub extends Id {

}