<?php namespace spec\OrderFulfillment\EventSourcing;

use OrderFulfillment\EventSourcing\Id;

class TestIdTwo extends Id  {}