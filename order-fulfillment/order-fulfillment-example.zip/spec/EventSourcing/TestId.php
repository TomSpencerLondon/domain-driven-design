<?php namespace spec\OrderFulfillment\EventSourcing;

use OrderFulfillment\EventSourcing\Id;

class TestId extends Id  {}