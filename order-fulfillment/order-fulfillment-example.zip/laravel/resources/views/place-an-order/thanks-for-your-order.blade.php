@extends('customer-layout')

@section('content')
    <div class="uk-container">
        Thank you for your order.
    </div>
@endsection