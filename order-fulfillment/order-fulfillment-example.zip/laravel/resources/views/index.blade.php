<ul>
    <li><a href="/place-an-order/view-products">Place Order</a></li>
    <li><a href="/confirm-order">Confirm Order</a></li>
    <li><a href="/make-a-payment/choose-an-order">Make Payment</a></li>
    <li><a href="/fulfill-an-order/choose-an-order">Fulfill Order</a></li>
</ul>