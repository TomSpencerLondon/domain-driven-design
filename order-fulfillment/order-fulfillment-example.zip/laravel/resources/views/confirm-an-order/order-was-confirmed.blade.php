@extends('employee-layout')

@section('content')
    <div class="uk-container">
        The order was confirmed.
    </div>
@endsection