<?php $__env->startSection('content'); ?>
    <div class="uk-card uk-background-default uk-position-center uk-card-body uk-box-shadow-large uk-width-auto">
        <h3 class="uk-card-title">Fulfill Orders</h3>

        <form class="uk-form-width-large">
            <ul class="uk-list">
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li>
                        <strong>Order <?php echo e($order->customer_name); ?></strong> placed <?php echo e($order->placedAt()); ?>

                        <div><?php echo e($order->delimitedProductList()); ?></div>
                        <div><?php echo e($order->totalPriceWithCurrency()); ?></div>
                        <a href="/fulfill-an-order/fulfill-order/<?php echo e($order->orderId()); ?>">Make a payment on this order.</a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li>No orders have been completed.</li>
                <?php endif; ?>
            </ul>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employee-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>