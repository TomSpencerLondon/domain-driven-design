<?php $__env->startSection('content'); ?>
    <div class="uk-card uk-background-default uk-position-center uk-card-body uk-box-shadow-large uk-width-auto">
        <h3 class="uk-card-title">Make a Payment</h3>

        <p>Order # <?php echo e($order->orderId()); ?></p>
        <p>Total Order Price: <?php echo e($order->totalPriceWithCurrency()); ?></p>

        <p>Payments<br/>
            <?php if($payments->isEmpty()): ?>
                No payments have been made on this order.
            <?php else: ?>
                <ul class="uk-list">
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <strong>Payment</strong>
                            <?php echo e($payment->amountWithCurrency()); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </p>

        <form method="post" class="uk-form-width-large">
            <ul class="uk-list">
                <li>
                    Amount: <input type="text" name="payment_amount"/>
                </li>
                <li>
                    Credit Card
                    <input type="text" name="credit_card_number" value="4222 2222 2222 2222"/>
                </li>
                <li>
                    <input type="submit" value="Make Payment"/>
                </li>
            </ul>
        </form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>