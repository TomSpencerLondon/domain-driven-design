<?php $__env->startSection('content'); ?>
    <div class="uk-container">
        The order was fulfilled.
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employee-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>