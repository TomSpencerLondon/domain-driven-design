<?php $__env->startSection('content'); ?>
    <div class="uk-container">

        <h1 class="uk-card-title">Select an Order to Confirm</h1>

        <ul class="uk-list">
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                    <strong>Order <?php echo e($order->customer_name); ?></strong> placed <?php echo e($order->placedAt()); ?>

                    <div><?php echo e($order->delimitedProductList()); ?></div>
                    <div><?php echo e($order->totalPriceWithCurrency()); ?></div>
                    <a href="/confirm-an-order/confirm-order/<?php echo e($order->orderId()); ?>">Confirm</a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p><li>no orders</li></p>
            <?php endif; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employee-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>