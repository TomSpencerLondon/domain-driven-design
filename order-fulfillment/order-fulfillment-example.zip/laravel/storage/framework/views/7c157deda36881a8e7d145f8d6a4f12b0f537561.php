<?php $__env->startSection('content'); ?>
    <div class="uk-card uk-background-default uk-position-center uk-card-body uk-box-shadow-large uk-width-auto">
        <h3 class="uk-card-title">Fulfill Orders</h3>

        <form class="uk-form-width-large">
            <ul class="uk-list">
                <li>
                    <strong>Order 1</strong>
                    <div>Product 1, Product 2</div>
                    <a href="#">Fulfill</a>
                </li>
                <li>
                    <strong>Order 2</strong>
                    <div>Product 2</div>
                    <a href="#">Fulfill</a>
                </li>
            </ul>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employee-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>