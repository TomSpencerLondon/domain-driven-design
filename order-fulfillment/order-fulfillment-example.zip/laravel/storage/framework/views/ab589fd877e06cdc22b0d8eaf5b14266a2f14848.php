<?php $__env->startSection('content'); ?>
    <div class="uk-card uk-background-default uk-position-center uk-card-body uk-box-shadow-large uk-width-auto">
        <h3 class="uk-card-title">Your payment was received.</h3>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>